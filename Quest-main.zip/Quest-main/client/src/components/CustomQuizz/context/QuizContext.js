import React from "react";
const QuizContext = React.createContext();
export default QuizContext;
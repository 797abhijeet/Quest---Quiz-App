import React from "react";
const UserQuizContext = React.createContext();
export default UserQuizContext;
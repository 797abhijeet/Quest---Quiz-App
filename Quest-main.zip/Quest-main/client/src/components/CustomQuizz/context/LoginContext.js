import React from "react";
const LoginContext = React.createContext();
export default LoginContext;